"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
require("dotenv/config");
const logger_1 = __importDefault(require("../utils/logger"));
const storedKey = process.env.API_KEY;
const verifyApiKey = (req, res, next) => {
    const apiKey = req.headers["x-api-key"];
    if (apiKey === storedKey) {
        next();
    }
    else if (!apiKey || apiKey !== storedKey) {
        logger_1.default.error(`invalid API key attempt from ${req.host}`);
        res.status(400).json({ message: "Unauthorized: invalid API key" });
    }
    else {
        logger_1.default.error(`unknown error validating access from ${req.host}`);
        res.status(400).json({ message: "Unknown error" });
    }
};
exports.default = verifyApiKey;
//# sourceMappingURL=auth.js.map