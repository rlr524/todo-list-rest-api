"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = getSecrets;
const client_secrets_manager_1 = require("@aws-sdk/client-secrets-manager");
const credential_provider_ini_1 = require("@aws-sdk/credential-provider-ini");
require("dotenv/config");
const logger_1 = __importDefault(require("./logger"));
let response;
async function getSecrets() {
    const profile = process.env.AWS_PROFILE;
    const client = new client_secrets_manager_1.SecretsManagerClient({
        region: "us-west-2",
        credentials: (0, credential_provider_ini_1.fromIni)({ profile: profile }),
    });
    const params = {
        SecretId: process.env.SECRET_NAME,
    };
    try {
        response = await client.send(new client_secrets_manager_1.GetSecretValueCommand(params));
    }
    catch (err) {
        logger_1.default.error("error", err);
    }
    return response;
}
//# sourceMappingURL=awsSecrets.js.map