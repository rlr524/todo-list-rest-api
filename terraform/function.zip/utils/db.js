"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = connectDB;
const mongoose_1 = __importDefault(require("mongoose"));
require("dotenv/config");
const awsSecrets_1 = __importDefault(require("./awsSecrets"));
async function connectDB() {
    const response = await (0, awsSecrets_1.default)();
    const secrets = response.SecretString ?? "";
    const secretValues = JSON.parse(secrets);
    const user = secretValues.MONGO_DB_USER;
    const password = secretValues.MONGO_DB_PASSWORD;
    const DB_URL = `mongodb+srv://${user}:${password}@cluster0.jnsctan.mongodb.net/todo?retryWrites=true&w=majority&appName=Cluster0`;
    await mongoose_1.default.connect(DB_URL);
}
//# sourceMappingURL=db.js.map