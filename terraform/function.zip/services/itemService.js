"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const item_1 = require("../models/item");
const mongoose_1 = require("mongoose");
const logger_1 = __importDefault(require("../utils/logger"));
const ItemService = {
    async getItems(req, res) {
        const items = await item_1.Item.find({});
        res.json(items);
        logger_1.default.info(`get items invoked - from ${req.host}`);
    },
    async getActiveItems(req, res) {
        const items = await item_1.Item.find({
            deleted: false,
        });
        res.json(items);
        logger_1.default.info(`get active items invoked - from ${req.host}`);
    },
    async getItemById(req, res) {
        const id = new mongoose_1.Types.ObjectId(req.params.id);
        try {
            const item = await item_1.Item.findById(id);
            if (!item) {
                res.json(`get item by id invoked - item with the id of ${id} not found`);
                logger_1.default.info(`get item by id invoked - unsuccessful on item id ${id} from ${req.host}`);
                return;
            }
            res.json(item);
            logger_1.default.info(`get item by id invoked - on item id ${id} from ${req.host}`);
        }
        catch (err) {
            if (err instanceof Error && err.name === "CastError") {
                res.json(`invalid id format`);
                logger_1.default.error(`get item by id invoked - invalid id format: ${err.message} from ${req.host}`);
            }
            else {
                res.json(`an unknown error occurred`);
                if (err instanceof Error) {
                    logger_1.default.error(`get item by id invoked - an unknown error occurred: ${err.message} from ${req.host}`);
                }
                else {
                    logger_1.default.error(`get item by id invoked - an unknown error occurred: ${JSON.stringify(err)} from ${req.host}`);
                }
            }
        }
    },
    async createItem(req, res) {
        const body = req.body;
        const item = await item_1.Item.insertOne({
            title: body.title,
            description: body.description,
            due: body.due,
            importance: body.importance
                ? body.importance
                : (body.importance = "Medium"),
            complete: (body.complete = false),
            owner: body.owner ? body.owner : (body.owner = "Rob"),
            deleted: (body.deleted = false),
        });
        res.json(item);
        logger_1.default.info(`create item invoked - returning id ${item.id} from ${req.host}`);
    },
    async updateItem(req, res) {
        const id = req.body.id;
        const { title, description, due, importance, complete, owner } = req.body;
        try {
            const item = await item_1.Item.findOneAndUpdate({ _id: id }, {
                title: title,
                description: description,
                due: due,
                importance: importance,
                complete: complete,
                owner: owner,
                deleted: false,
            }, { new: true });
            if (!item) {
                res.json(`item with the id of ${id} not found`);
                logger_1.default.info(`update item invoked - item with the id of ${id} not found from ${req.host}`);
                return;
            }
            res.json(item);
            logger_1.default.info(`update item invoked - item with id ${id} from ${req.host}`);
        }
        catch (err) {
            if (err instanceof Error && err.name === "CastError") {
                res.json(`invalid id format`);
                logger_1.default.error(`update item invoked - invalid id format: ${err.message} from ${req.host}`);
            }
            else {
                res.json(`an unknown error occurred`);
                if (err instanceof Error) {
                    logger_1.default.error(`update item invoked - an unknown error occurred: ${err.message} from ${req.host}`);
                }
                else {
                    logger_1.default.error(`update item invoked - an unknown error occurred: ${JSON.stringify(err)} from ${req.host}`);
                }
            }
        }
    },
    async deleteItem(req, res) {
        const id = new mongoose_1.Types.ObjectId(req.params.id);
        try {
            const item = await item_1.Item.findOneAndUpdate({ _id: id }, {
                deleted: true,
            }, { new: true });
            if (!item) {
                res.json(`item with the id of ${id} not found`);
                logger_1.default.info(`delete item invoked - item with the id of ${id} not found from ${req.host}`);
                return;
            }
            res.json(item);
            logger_1.default.info(`delete item invoked - item with the id ${id}`);
        }
        catch (err) {
            if (err instanceof Error && err.name === "CastError") {
                res.json(`invalid id format`);
                logger_1.default.error(`delete item invoked - invalid id format: ${err.message} from ${req.host}`);
            }
            else {
                res.json(`an unknown error occurred`);
                if (err instanceof Error) {
                    logger_1.default.error(`delete item invoked - an unknown error occurred: ${err.message} from ${req.host}`);
                }
                else {
                    logger_1.default.error(`delete item invoked - an unknown error occurred: ${JSON.stringify(err)} from ${req.host}`);
                }
            }
        }
    },
};
exports.default = ItemService;
//# sourceMappingURL=itemService.js.map