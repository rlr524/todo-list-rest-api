"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Item = void 0;
const mongoose_1 = require("mongoose");
const itemSchema = new mongoose_1.Schema({
    title: { type: String, required: true },
    description: { type: String, required: false },
    due: { type: String, required: false },
    importance: { type: String, required: false },
    complete: { type: Boolean, required: false },
    owner: { type: String, required: true },
    deleted: { type: Boolean, required: true },
}, { toJSON: { virtuals: true }, timestamps: true });
exports.Item = (0, mongoose_1.model)("Item", itemSchema);
//# sourceMappingURL=item.js.map