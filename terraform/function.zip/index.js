"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
require("dotenv/config");
const db_1 = __importDefault(require("./utils/db"));
const itemService_1 = __importDefault(require("./services/itemService"));
//import verifyApiKey from "./middlewares/auth";
const logger_1 = __importDefault(require("./utils/logger"));
const serverless_http_1 = __importDefault(require("serverless-http"));
const app = (0, express_1.default)();
const port = process.env.PORT || "3000";
app.get("/", (req, res) => {
    res.status(200).send("Hello, Madison");
});
const version = process.env.API_VERSION;
(0, db_1.default)().catch((err) => logger_1.default.error(err));
app.use((0, cors_1.default)());
app.use((0, helmet_1.default)());
app.use(express_1.default.json());
//app.use(verifyApiKey);
app.get(`/api/${version}/items`, itemService_1.default.getActiveItems);
app.get(`/api/${version}/item/:id`, itemService_1.default.getItemById);
app.post(`/api/${version}/item`, itemService_1.default.createItem);
app.patch(`/api/${version}/item`, itemService_1.default.updateItem);
app.delete(`/api/${version}/item/:id`, itemService_1.default.deleteItem);
app.listen(port, () => {
    console.log(`The service has started on port ${port}`);
});
exports.handler = (0, serverless_http_1.default)(app);
//# sourceMappingURL=index.js.map